def potencia(n1,n2):
          print("la potencia de  ",n1 ,"A",n2, " es: " , n1**n2 )

def redondear(n1):
          print("se aproximo el numero a : ",round(n1))